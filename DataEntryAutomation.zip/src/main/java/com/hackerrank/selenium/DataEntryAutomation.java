package com.hackerrank.selenium;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class DataEntryAutomation {

    public static void fillDateOfBirth(WebDriver driver, String pageUrl) {
        driver.get(pageUrl);
        Select month=new Select(driver.findElement(By.id("month")));
        month.selectByVisibleText("July");
        Select day=new Select(driver.findElement(By.id("day")));
        day.selectByVisibleText("11");
        Select year=new Select(driver.findElement(By.id("year")));
        year.selectByVisibleText("1990");
        
    }

    public static void answerQuestions(WebDriver driver, String pageUrl) {
        driver.get(pageUrl);
        driver.findElement(By.xpath("//input[@value='Java']")).click();
        driver.findElement(By.xpath("//input[@value='Python']")).click();
        driver.findElement(By.xpath("//input[@value='Linux']")).click();
        driver.findElement(By.xpath("//input[@value='Mac OSX']")).click();
        driver.findElement(By.xpath("//input[@value='IntelliJ IDEA']")).click();

    }
}
