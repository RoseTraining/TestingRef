package com.hackerrank.selenium;

import org.openqa.selenium.WebDriver;

public class OnlineSurvey {

    public static void fillDateOfBirth(WebDriver driver, String pageUrl) {
        // complete implementation
    }

    public static void answerQuestions(WebDriver driver, String pageUrl) {
        // complete implementation
    }
}
