## Environment
- Java version: 17
- Maven version: 3.*
- Selenium HtmlUnitDriver: 2.52.0

## Read-Only Files
- src/test/*
- website/*
- src/main/java/com/hackerrank/selenium/server/*

## Commands
- run: 
```bash
mvn clean package && java -jar target/selenium-java-healthcare-analytics-1.0.jar
```
- install: 
```bash
mvn clean install
```
- test: 
```bash
mvn clean test
```

## Requirements

In this challenge, you are going to use the Selenium WebDriver, the HtmlUnitDriver, which uses the HtmlUnit headless browser. This means you don't need to set up a browser (like Firefox or Chrome) or a web driver executable (like FirefoxDriver or ChromeDriver). Every web page has web elements (aka DOM objects) with unique names or IDs. Names are usually unique, but this is not a restriction.

Given a URL for a dummy healthcare data analytics web application that shows the patients' data in a table, verify that each member's total paid amount is the sum of that member's claims amount by drilling down on the member's "Total Paid Amount" column and performing a summation of the values.

The class `HealthcareAnalytics` has a single method:

`List<String> findAmountMismatchedPatients(WebDriver driver, String patientPageUrl)`:
- Browse the _patientPageUrl_ and drill down on each member's total paid amount column.
  - The source code structure of _patientPageUrl_ is like _website/patientsPage.html_.
- Upon drilling down on the total paid amount of a member, another page opens up that contains a table of the member's claims data.
  - The source code structure of the claims data is like _website/claimsPage.html_.
- For each member, sum the "Total Paid Amount" column for their claims.
- Return the members whose total paid amount before the drill-down does not match the sum of claims amounts after the drill-down.

_patientPageUrl_ is the URL of the patients' aggregated data.

There are tests for the correctness of each method. You can make use of these tests while debugging/checking your implementation. The test's setup method bootstraps an embedded jetty server and deploys a small web app that displays a randomly generated website. The example website is given in the `website` folder, where you can view the structure of the patient and claims pages, but the data displayed is random and will change on every refresh.

The patient page looks like this:

![web page1](patientPage.png)

The claims page looks like this:

![web page2](claimsPage.png)

Your task is to complete the implementation of `HealthcareAnalytics` so that the unit tests pass while running the tests.
