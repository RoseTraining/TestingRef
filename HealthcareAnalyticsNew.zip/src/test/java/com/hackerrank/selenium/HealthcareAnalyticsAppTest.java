package com.hackerrank.selenium;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.hackerrank.selenium.server.JettyServer;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

public class HealthcareAnalyticsAppTest {
    private static JettyServer server = null;
    private static WebDriver driver = null;
    private static int TEST_PORT = 8001;

    private static String patientPageUrl = "http://localhost:"+TEST_PORT+"/patients";
    private static String seedPageUrl = "http://localhost:"+TEST_PORT+"/seed";

    private static Integer patientSeed = 0;
    private static Integer amountSeed = 0;

    @BeforeClass
    public static void setup() {
        driver = new HtmlUnitDriver(BrowserVersion.CHROME, true) {
            @Override
            protected WebClient newWebClient(BrowserVersion version) {
                WebClient webClient = super.newWebClient(version);
                webClient.getOptions().setThrowExceptionOnScriptError(false);

                java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);
                java.util.logging.Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.OFF);

                return webClient;
            }
        };
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        server = new JettyServer(TEST_PORT);
        server.start();

        //rands
        patientSeed = new Random().nextInt(10) + 3;
        amountSeed = new Random().nextInt(200) + 99;

        //set seeds
        driver.get(seedPageUrl + "?patientSeed=" + patientSeed + "&amountSeed=" + amountSeed);
    }

    @AfterClass
    public static void tearDown() {
        driver.close();
        server.stop();
    }

    @Test
    public void testFindAmountMismatchedPatients() {
        List<String> actual = HealthcareAnalytics.findAmountMismatchedPatients(driver, patientPageUrl);

        List<String> expected = new ArrayList<>();
        for (int i = 1; i <= patientSeed; i++) {
            if ((amountSeed + i) % i != 0) {
                expected.add("" + i);
            }
        }

        System.out.println(" Actual: \n" + actual + "\n Expected: \n" + expected);

        Assert.assertEquals(expected.size(), actual.size());
        for (String actualPatientId : actual) {
            Assert.assertTrue(expected.contains(actualPatientId));
        }
    }
}
