package com.hackerrank.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

public class HealthcareAnalytics {

    public static List<String> findAmountMismatchedPatients(WebDriver driver, String patientPageUrl) {
        driver.get(patientPageUrl);
        List<String> mismatch = new ArrayList<>();
        //List<WebElement> names = driver.
        //findElements(By.xpath("//table//tbody/tr//td[1]"));
        List<WebElement> links = driver.
        findElements(By.xpath("//table//tbody/tr//td[4]/a"));
        for(int i=0; i<links.size(); i++){
            int total=Integer.parseInt(links.get(i).getText());
            //String nameee=names.get(i).getText();
            links.get(i).click();
             List<WebElement> num = driver.
        findElements(By.xpath("//table//tbody/tr//td[3]"));
        List<WebElement> names = driver.
        findElements(By.xpath("//table//tbody/tr//td[1]"));
        int sum=0;
        for(WebElement number:num){
            sum+=Integer.parseInt(number.getText());
        }
        if(sum!=total){
            mismatch.add(names.get(i).getText());
        }
        driver.navigate().back();
        names = driver.
        findElements(By.xpath("//table//tbody/tr//td[1]"));
        links = driver.
        findElements(By.xpath("//table//tbody/tr//td[4]/a"));

        }
        return mismatch;
    }
}
            