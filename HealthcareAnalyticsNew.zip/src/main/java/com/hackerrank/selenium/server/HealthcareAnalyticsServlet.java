package com.hackerrank.selenium.server;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.RandomStringUtils;

import java.io.IOException;

public class HealthcareAnalyticsServlet extends HttpServlet {
    public static final String footer = "</table>\n" +
            "</div>\n" +
            "<!--Patients Data-->\n" +
            "<h8k-navbar header=\"2001-2021\"></h8k-navbar>\n" +
            "</body>\n" +
            "</html>";

    private static final String head = "<html>\n" +
            "<head>\n" +
            "    <title>Hackerrank Healthcare Analytics</title>\n" +
            "    <link href=\"https://cdn.jsdelivr.net/npm/h8k-design@1.0.16/dist/index.css\" rel=\"stylesheet\"/>\n" +
            "    <script src=\"https://cdn.jsdelivr.net/npm/h8k-components@1.0.0/dist/h8k-components/h8k-components.esm.js\"\n" +
            "            type=\"module\"></script>\n" +
            "    <script nomodule src=\"https://cdn.jsdelivr.net/npm/h8k-components@1.0.0/dist/h8k-components/h8k-components.js\"></script>\n" +
            "</head>\n" +
            "<body>\n" +
            "<h8k-navbar fixed header=\"Hackerrank Healthcare Analytics\"></h8k-navbar>\n" +
            "\n" +
            "<div class=\"mx-auto w-50 mt-100 paragraph\">\n" +
            "    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore</p>\n" +
            "</div>\n" +
            "\n" +
            "<!--Patients Data-->\n" +
            "<div align=\"center\">\n" +
            "    <table>";

    private static Integer patientSeed = 0;
    private static Integer amountSeed = 0;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("Server->Processing URL: " + request.getRequestURL());

        response.setHeader("Cache-Control", "private, no-cache");
        response.setHeader("Pragma", "no-cache");
        response.setCharacterEncoding("UTF-8");

        StringBuilder builder = new StringBuilder();
        builder.append(head);

        if ("/seed".equals(request.getRequestURI())) {
            patientSeed = Integer.parseInt(request.getParameter("patientSeed"));
            amountSeed = Integer.parseInt(request.getParameter("amountSeed"));
        } else if ("/patients".equals(request.getRequestURI())) {
            builder.append("<thead>");
            builder.append("<tr>");
            builder.append("<th>");
            builder.append("Patient Id");
            builder.append("</th>");

            builder.append("<th>");
            builder.append("Name");
            builder.append("</th>");

            builder.append("<th>");
            builder.append("Age");
            builder.append("</th>");

            builder.append("<th>");
            builder.append("Total Paid Amount");
            builder.append("</th>");

            builder.append("</tr>");
            builder.append("</thead>");
            builder.append("<tbody>");
            for (int i = 1; i <= patientSeed; i++) {
                builder.append("<tr>");

                builder.append("<td>");
                builder.append(i);
                builder.append("</td>");

                builder.append("<td>");
                builder.append(RandomStringUtils.random(i + 5, "abcdefghij"));
                builder.append("</td>");

                builder.append("<td>");
                builder.append(i + 20);
                builder.append("</td>");

                builder.append("<td>");
                builder.append("<a href=\"claims?p=" + i + "\">");
                builder.append(amountSeed + i);
                builder.append("</a>");
                builder.append("</td>");

                builder.append("</tr>");
            }
            builder.append("</tbody>");
        } else if ("/claims".equals(request.getRequestURI())) {
            Integer p = Integer.parseInt(request.getParameter("p"));
            Integer amount = (amountSeed + p) / p;

            builder.append("<thead>");
            builder.append("<tr>");
            builder.append("<th>");
            builder.append("Patient Id");
            builder.append("</th>");

            builder.append("<th>");
            builder.append("Claim ID");
            builder.append("</th>");

            builder.append("<th>");
            builder.append("Paid Amount");
            builder.append("</th>");

            builder.append("</tr>");
            builder.append("</thead>");
            builder.append("<tbody>");
            for (int j = 1; j <= p; j++) {
                builder.append("<tr>");

                builder.append("<td>");
                builder.append(p);
                builder.append("</td>");

                builder.append("<td>");
                builder.append(j);
                builder.append("</td>");

                builder.append("<td>");
                builder.append(amount);
                builder.append("</td>");

                builder.append("</tr>");
            }
            builder.append("</tbody>");
        }

        builder.append(footer);
        response.getWriter().write(builder.toString());
    }
}
