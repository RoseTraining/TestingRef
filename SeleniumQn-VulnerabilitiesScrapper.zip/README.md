## Environment:
- Java version: 17
- Maven version: 3.*
- Selenium HtmlUnitDriver: 2.52.0

## Read-Only Files:
- src/test/*
- website/*
- src/main/java/com/hackerrank/selenium/server/*

## Requirements:
In this challenge, you are going to use selenium web driver, the HtmlUnitDriver, which uses HtmlUnit headless browser. So you neither need to setup the browsers like Firefox, Chrome nor a web driver executables like FirefoxDriver, ChromeDriver.
You are given a dummy website like nvd.com or cvedetails.com which shows all the WordPress vulnerabilities of all the WordPress versions in a tabular format. Now your task is to scrap all the vulnerabilities of a given WordPress version.

There is a class `VulnerabilitiesScraper` which has 2 methods:
 
`List<String> scrapVulnerabilitiesOf(WebDriver driver, String vulnPageUrl, String wpVersion)`:
 - browse the `vulnPageUrl` and filter rows having given `wpVersion` and collect `CVE ID` column.
 - its source code structure is like `website/vulnPage.html`.
 - it should return a list of CVE IDs of given `wpVersion`.
 
`String topVulnerabilityOf(WebDriver driver, String vulnPageUrl, String wpVersion)`:
 - browse the `vulnPageUrl` and find the row with highest score having `wpVersion` and collect the corresponding `CVE Id`.
 - its source code structure is like `website/vulnPage.html`.
 - vulnerability score is unique across same `wpVersion`.
 - it should return the `CVE ID` of a highest scored vulnerability.
  
where the `vulnPageUrl` is the URL of the vulnerabilities page and `wpVersion` is the version of which vulnerabilities to be scraped.

There are tests for testing correctness of each methods. So you can make use of these tests while debugging/checking your implementation.
The test's setup method bootstraps an embedded jetty server and deploys small web app which displays randomly generated website. 
The example website is given in the `website` folder where you can view the structure of search page and result page but data displayed are random and will change on every refresh.

The provided vulnerabilities page will look like: 

![web page](vulnPage.png)

Your task is to complete the implementation of those 2 methods so that the unit tests pass while running the tests.

## Commands
- run: 
```bash
mvn clean package -DskipTests && java -jar target/selenium-java-vulnerabilities-scraping-1.0.jar
```
- install: 
```bash
mvn clean install
```
- test: 
```bash
mvn clean test
```