package com.hackerrank.selenium.server;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

public class VulnerabilitiesServlet extends HttpServlet {
    public static final String footer = "</table>\n" +
            "    </div>\n" +
            "</div>\n" +
            "<!--Vulnerabilities end-->\n" +
            "\n" +
            "<h8k-navbar header=\"2001-2021\"></h8k-navbar>\n" +
            "</body>\n" +
            "</html>";
    private static final String head = "<html>\n" +
            "<head>\n" +
            "    <title>Hackerrank Wordpress Vulnerabilities</title>\n" +
            "    <link href=\"https://cdn.jsdelivr.net/npm/h8k-design@latest/dist/index.css\" rel=\"stylesheet\"/>\n" +
            "    <script src=\"https://cdn.jsdelivr.net/npm/h8k-components/dist/h8k-components/h8k-components.esm.js\"\n" +
            "            type=\"module\"></script>\n" +
            "    <script nomodule src=\"https://cdn.jsdelivr.net/npm/h8k-components/dist/h8k-components/h8k-components.js\"></script>\n" +
            "    <link href=\"css/style.css\" rel=\"stylesheet\"/>\n" +
            "    <style>\n" +
            "        .paragraph p {\n" +
            "            font-size: 0.95em;\n" +
            "            text-align: justify;\n" +
            "        }\n" +
            "        table tbody tr td {\n" +
            "            padding: 16px;\n" +
            "        }\n" +
            "        strong {\n" +
            "        color:Green\n" +
            "        }\n" +
            "\n" +
            "\n" +
            "    </style>\n" +
            "</head>\n" +
            "<body>\n" +
            "<h8k-navbar fixed header=\"Hackerrank Wordpress Vulnerabilities\"></h8k-navbar>\n" +
            "\n" +
            "<div class=\"mx-auto w-50 mt-100 paragraph\">\n" +
            "    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore</p>\n" +
            "</div>\n" +
            "\n" +
            "<!--WP Vulnerabilities-->\n" +
            "<div align=\"center\">\n" +
            "    <table>";
    private static Integer versionSeed = 0;
    private static Integer rowSeed = 0;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setHeader("Cache-Control", "private, no-cache");
        response.setHeader("Pragma", "no-cache");
        response.setCharacterEncoding("UTF-8");

        if ("/seed".equals(request.getRequestURI())) {
            System.out.println("Server->Processing URL: " + request.getRequestURL());
            versionSeed = Integer.parseInt(request.getParameter("versionSeed"));
            rowSeed = Integer.parseInt(request.getParameter("rowSeed"));
        } else if ("/vuln".equals(request.getRequestURI())) {
            System.out.println("Server->Processing URL: " + request.getRequestURL());
            StringBuilder builder = new StringBuilder();

            builder.append(head);
            builder.append("<tr>");
            builder.append("<th>");
            builder.append("CVE ID");
            builder.append("</th>");

            builder.append("<th>");
            builder.append("Publish Date");
            builder.append("</th>");
            builder.append("<th>");
            builder.append("Update Date");
            builder.append("</th>");

            builder.append("<th>");
            builder.append("Score");
            builder.append("</th>");
            builder.append("<th>");
            builder.append("WordPress Version");
            builder.append("</th>");

            builder.append("</tr>");

            for (int i = 1; i <= versionSeed; i++) {
                for (int j = 1; j <= rowSeed; j++) {
                    builder.append("<tr>");
                    builder.append("<td>");
                    builder.append(i + "" + j);
                    builder.append("</td>");

                    builder.append("<td>");
                    builder.append("publish_date");
                    builder.append("</td>");
                    builder.append("<td>");
                    builder.append("update_date");
                    builder.append("</td>");

                    builder.append("<td>");
                    builder.append(j + "" + i);
                    builder.append("</td>");
                    builder.append("<td>");
                    builder.append(i);
                    builder.append("</td>");
                    builder.append("</tr>");
                }
            }

            builder.append(footer);
            response.getWriter().write(builder.toString());
        }
    }
}
