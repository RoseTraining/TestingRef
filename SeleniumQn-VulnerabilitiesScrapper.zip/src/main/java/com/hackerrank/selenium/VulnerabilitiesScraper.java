package com.hackerrank.selenium;

import org.openqa.selenium.WebDriver;

import java.util.List;

public class VulnerabilitiesScraper {

    public static List<String> scrapeVulnerabilitiesOf(WebDriver driver, String vulnPageUrl, String wpVersion) {
       return null;
    }

    public static String findHighestScoredVulnerability(WebDriver driver, String vulnPageUrl, String wpVersion) {
        return null;
    }
}
