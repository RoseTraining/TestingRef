package com.hackerrank.selenium;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.hackerrank.selenium.server.JettyServer;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

public class VulnerabilitiesScraperTest {
    private static JettyServer server = null;
    private static int TEST_PORT = 8001;
    private static WebDriver driver = null;

    private static String vulnPageUrl = "http://localhost:" + TEST_PORT + "/vuln";
    private static String seedPageUrl = "http://localhost:" + TEST_PORT + "/seed";

    private static Integer versionSeed = 0;
    private static Integer rowSeed = 0;

    @BeforeClass
    public static void setup() {
        driver = new HtmlUnitDriver(BrowserVersion.CHROME, true) {
            @Override
            protected WebClient newWebClient(BrowserVersion version) {
                WebClient webClient = super.newWebClient(version);
                webClient.getOptions().setThrowExceptionOnScriptError(false);

                java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);
                java.util.logging.Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.OFF);

                return webClient;
            }
        };
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        server = new JettyServer(TEST_PORT);
        server.start();

        //rands
        versionSeed = new Random().nextInt(5) + 5;
        rowSeed = new Random().nextInt(5) + 5;

        //set seeds
        driver.get(seedPageUrl + "?versionSeed=" + versionSeed + "&rowSeed=" + rowSeed);
    }

    @AfterClass
    public static void tearDown() {
        driver.close();
        server.stop();
    }

    @Test
    public void testScrapVulnerabilitiesOf() {
        Integer wpVersion = versionSeed;
        List<String> actual = VulnerabilitiesScraper.scrapeVulnerabilitiesOf(driver, vulnPageUrl, "" + wpVersion);

        List<String> expected = new ArrayList<>();
        for (int j = 1; j <= rowSeed; j++) {
            expected.add(versionSeed + "" + j);
        }

        System.out.println(" Actual: \n" + actual + "\n Expected: \n" + expected);

        Assert.assertEquals(expected.size(), actual.size());
        for (String actualCveId : actual) {
            Assert.assertTrue(expected.contains(actualCveId));
        }
    }

    @Test
    public void testFindHighestScoredVulnerability() {
        Integer wpVersion = versionSeed;
        String actual = VulnerabilitiesScraper.findHighestScoredVulnerability(driver, vulnPageUrl, "" + versionSeed);

        String expected = wpVersion + "" + rowSeed;

        System.out.println(" Actual: \n" + actual + "\n Expected: \n" + expected);

        Assert.assertEquals(expected, actual);
    }
}
