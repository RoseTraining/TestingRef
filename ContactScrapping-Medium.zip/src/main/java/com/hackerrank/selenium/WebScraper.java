package com.hackerrank.selenium;

import org.openqa.selenium.WebDriver;

import java.util.List;

public class WebScraper {

    public static List<String> scrapeEmailAddresses(WebDriver driver, String pageUrl) {
        return null;
    }

    public static List<String> scrapeMobileNumbers(WebDriver driver, String pageUrl) {
        return null;
    }
}
