## Environment
- Java version: 17
- Maven version: 3.*
- HtmlUnitDriver: 4.13.0

## Read-Only Files
- src/test/*
- website/*

## Commands
- run: 
```bash
mvn clean package && java -jar target/selenium-java-element-locator-1.0.jar
```
- install: 
```bash
mvn clean install
```
- test: 
```bash
mvn clean test
```

## Requirements
In this challenge, you are going to use the Selenium WebDriver, the _HtmlUnitDriver_, which uses the _HtmlUnit_ headless browser. This means you don't need to set up a browser (like Firefox or Chrome) or a web driver executable (like FirefoxDriver or ChromeDriver). Every web page has web elements (aka DOM objects) with unique names or IDs. Names are usually unique, but this is not a restriction.

There is a class _ElementLocator_ that has 4 methods:

1. _locateNonTextTypeElements_: This needs to return *input* elements whose type is not *text* and are inside the *form*.
2. _locateContactElements_: This needs to return *input* elements whose *name* starts with *contact* and are inside the *form*.
3. _locateSubmitElement_: This needs to return *button* element having type *submit*. Assume there can be only one submit type button element inside the form.
4. _locateIdMissingElements_: This needs to return *input* elements whose *id* attribute is missing and are inside the *form*.

These methods have 2 parameters, one web driver and one web page URL. The supplied web page has only one form and will look like the following:

![Contact form with fields for first name, last name, email, gender radio buttons, and a green submit button.](https://hrcdn.net/s3_pub/istreet-assets/as3nClhoxTw9j7364IT5sQ/webPage.png)

Your task is to complete the implementation of these 4 methods so that the unit tests pass while running the tests.

//find input elements inside form
List elements = ElementLocator.locateNonTextTypeElements(driver, &quot;file:///selenium-java-base/website/home.html&quot;);

//Print
System.out.println(&quot;Elements:&quot;  + elements.size());
```
