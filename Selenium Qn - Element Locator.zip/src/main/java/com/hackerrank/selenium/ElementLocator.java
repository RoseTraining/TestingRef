package com.hackerrank.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class ElementLocator {

    public static List<WebElement> locateNonTextTypeElements(WebDriver driver, String pageUrl) {
        //complete implementation
        return null;
    }

    public static List<WebElement> locateContactElements(WebDriver driver, String pageUrl) {
        //complete implementation
        return null;
    }

    public static WebElement findSubmitElement(WebDriver driver, String pageUrl) {
        //complete implementation
        return null;
    }

    public static List<WebElement> locateIdMissingElements(WebDriver driver, String pageUrl) {
        //complete implementation
        return null;
    }
}