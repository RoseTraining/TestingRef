## Environment:
- Java version: 17
- Maven version: 3.*
- Selenium HtmlUnitDriver: 2.52.0

## Read-Only Files:
- src/test/*
- website/*
- src/main/java/com/hackerrank/selenium/server/*

## Contact Form Data
Fill the contact form with the following data:
- *First Name*: Fizz
- *Last Name*: Buzz
- *Email*: fizz_buzz@hackerrank.com
- *Phone*: 9823567490
- *Country*: Holy See (Vatican City State)
- *Message*: Hi there, This is me Fizz from VCS. Would you mind sending me your product details?

## Requirements:
In this challenge, you are going to use selenium web driver, the HtmlUnitDriver, which uses HtmlUnit headless browser. So you neither need to setup the browsers like Firefox, Chrome nor a web driver executables like FirefoxDriver, ChromeDriver.
Every web page has web elements(aka DOM objects) with unique names or IDs.

There is a class `AutoContacter` that has one method, `fillAndSubmitContactForm`:
 - It accepts 2 parameters, one web driver and one web page URL.
 - It needs to fill the Contact Us form with the given data and then submit.
 - The server will verify the submitted data with the given data.
 - Don't fill the hidden elements.

The page that will be supplied is _website/home.html_, which will look like the following:

![web page](webPage.png)

Your task is to complete the implementation of AutoContacter class so that the unit tests pass while running the tests.

## Commands
- run: 
```bash
mvn clean package && java -jar target/selenium-java-auto-contacter-1.0.jar
```
- install: 
```bash
mvn clean install
```
- test: 
```bash
mvn clean test
```
