package com.hackerrank.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
public class AutoContacter {

    public static void fillAndSubmitContactForm(WebDriver driver, String pageUrl) {
        driver.get(pageUrl);
        driver.findElement(By.id("fname")).sendKeys("Fizz");
         driver.findElement(By.id("lname")).sendKeys("Buzz"); driver.findElement(By.id("email")).sendKeys("fizz_buzz@hackerrank.com"); 
         driver.findElement(By.id("phone")).sendKeys("9823567490");
         Select sel = new Select(driver.findElement(By.id("country")));
         sel.selectByVisibleText("Holy See (Vatican City State)");
         driver.findElement(By.id("message")).sendKeys("Hi there, This is me Fizz from VCS. Would you mind sending me your product details?");
         driver.findElement(By.tagName("button")).submit();

    }
}
