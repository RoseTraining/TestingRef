package com.hackerrank.selenium;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.hackerrank.selenium.server.JettyServer;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AutoContacterTest {
    private static JettyServer server = null;
    private static WebDriver driver = null;
    private static int TEST_PORT = 8001;

    private static String pagUrl = "http://localhost:" + TEST_PORT + "/home.html";
    ;

    static Map<String, String> data = null;

    @BeforeClass
    public static void setup() {
        driver = new HtmlUnitDriver(BrowserVersion.CHROME, true) {

            @Override
            protected WebClient newWebClient(BrowserVersion version) {
                WebClient webClient = super.newWebClient(version);
                webClient.getOptions().setThrowExceptionOnScriptError(false);

                Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);
                Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.OFF);

                return webClient;
            }
        };
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        server = new JettyServer(TEST_PORT);
        server.start();

        data = new HashMap() {
            {
                put("fname", "Fizz");
                put("lname", "Buzz");
                put("email", "fizz_buzz@hackerrank.com,1010@hk.com");
                put("phone", "9823567490,1010");
                put("country", "Holy See (Vatican City State)");
                put("message", "Hi there, This is me Fizz from VCS. Would you mind sending me your product details?");
            }
        };
    }

    @Test
    public void testAutoContacter() {
        AutoContacter.fillAndSubmitContactForm(driver, pagUrl);

        for (Map.Entry<String, String> kv : data.entrySet()) {
            driver.get("http://localhost:" + TEST_PORT + "/contact?field=" + kv.getKey());
            String value = driver.findElement(By.tagName("body")).getText();
            Assert.assertEquals(kv.getValue(), value);
        }

    }

    @AfterClass
    public static void tearDown() {
        driver.close();
        server.stop();
    }
}
