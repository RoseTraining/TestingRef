package com.hackerrank.selenium;

import org.openqa.selenium.WebDriver;

import java.util.Map;

public class DataExtractor {

    public static Map<String, Integer> findTotalCasesByContinent(WebDriver driver, String pageUrl) {
        return null;
    }

    public static Map<String, Integer> findTotalCountryByContinent(WebDriver driver, String pageUrl) {
        return null;
    }
}
