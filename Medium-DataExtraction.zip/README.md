## Environment:
- Java version: 17
- Maven version: 3.*
- Selenium HtmlUnitDriver: 2.52.0

## Read-Only Files:
- src/test/*
- website/*
- src/main/java/com/hackerrank/selenium/server/*

## Requirements:
In this challenge, you are going to use the Selenium WebDriver, the HtmlUnitDriver, which uses the HtmlUnit headless browser. This means you don't need to set up the browser (like Firefox or Chrome) nor a web driver executable (like FirefoxDriver or ChromeDriver). Every web page has web elements (aka DOM objects) with unique names or ids.

The given page has a table with 5 columns: `country`, `total cases`, `total deaths`, `total recovered`, and `continent`.
 
There is a class `DataExtractor` that has 2 methods:
 
`findTotalCasesByContinent`:
 - Returns the sum of total cases by continent.
 - The return type of this method is Map, where the key is `continent` and the value is the sum of total cases of all the countries within the continent.
 - For example: [{"Asia",57890},{"Europe",34560},{...},...]
 
`findTotalCountryByContinent`:
 - Returns the count of countries by continent.
 - The return type of this method is Map, where the key is `continent` and the value is the count of all the countries within the continent.
 - For example: [{"Asia",4},{"Europe",20},{...},...]
 
These methods have 2 parameters, one web driver and one website URL.

There are tests for testing the correctness of each method. You can make use of these tests while debugging and checking your implementation. The test's setup method bootstraps an embedded jetty server and deploys a small web app that displays randomly generated and simplified COVID-19-like data at the URL `http://localhost:8000/home.html`. You can view the structure of the HTML page at `website/home.html`, but note that the data displayed are random and will change on every refresh.

The supplied website page will look like the following:

![web page](webPage.png)

Your task is to complete the implementation of those 2 methods so that the unit tests pass while running the tests.

## Commands
- run: 
```bash
mvn clean package && java -jar target/selenium-java-data-extraction-1.0.jar
```
- install: 
```bash
mvn clean install
```
- test: 
```bash
mvn clean test
```
