package com.hackerrank.selenium;

import org.openqa.selenium.WebDriver;

public class FormSubmission {

    public static void fillForm(WebDriver driver, String pageUrl) {
        // fill form code goes here
    }

    public static void submitForm(WebDriver driver) {
        // Assume this method is called only after calling fillForm(driver,url) method
    }
}