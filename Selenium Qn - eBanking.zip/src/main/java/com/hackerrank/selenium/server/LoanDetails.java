package com.hackerrank.selenium.server;

public class LoanDetails {
    public String firstName;
    public String lastName;
    public String email;
    public String loanType;
    public Integer loanDuration;

    public LoanDetails(String firstName, String lastName, String email, String loanType, Integer loanDuration) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.loanType = loanType;
        this.loanDuration = loanDuration;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLoanType() {
        return loanType;
    }

    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

    public Integer getLoanDuration() {
        return loanDuration;
    }

    public void setLoanDuration(Integer loanDuration) {
        this.loanDuration = loanDuration;
    }

    @Override
    public String toString() {
        return "LoanDetails{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", loanType='" + loanType + '\'' +
                ", loanDuration=" + loanDuration +
                '}';
    }

    @Override
    public int hashCode() {
        return firstName.hashCode() + lastName.hashCode() + email.hashCode() + loanDuration.hashCode() + loanDuration.hashCode();
    }
}
