package com.hackerrank.selenium.server;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

public class EBankingServlet extends HttpServlet {
    private static final String SUCCESS = "<html>\n" +
            "<head>\n" +
            "    <title>Hackerrank Bank: Loan Application Success</title>\n" +
            "</head>\n" +
            "<body>\n" +
            "<!--CODE-->\n" +
            "$code\n" +
            "<!--CODE-->\n" +
            "</body>\n" +
            "</html>";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        System.out.println("Server-->Processing: " + req.getRequestURL());
        res.setHeader("Cache-Control", "private, no-cache");
        res.setHeader("Pragma", "no-cache");
        res.setCharacterEncoding("UTF-8");

        LoanDetails loanDetails = new LoanDetails(
                req.getParameter("firstName") == null ? "" : req.getParameter("firstName"),
                req.getParameter("lastName") == null ? "" : req.getParameter("lastName"),
                req.getParameter("email") == null ? "" : req.getParameter("email"),
                req.getParameter("loanType") == null ? "" : req.getParameter("loanType"),
                req.getParameter("loanDuration") == null ? 0 : Integer.parseInt(req.getParameter("loanDuration")));

        res.getWriter().write(SUCCESS.replaceAll("\\$code", String.valueOf(loanDetails.hashCode())));
    }
}
