package com.hackerrank.selenium;

import com.hackerrank.selenium.server.LoanDetails;
import org.openqa.selenium.WebDriver;

public class EBankingApp {

    public static String applyLoan(WebDriver driver, String loanPageUrl, LoanDetails loanDetails) {
       return null;
    }
}
