package com.hackerrank.selenium;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.hackerrank.selenium.server.JettyServer;
import com.hackerrank.selenium.server.LoanDetails;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

public class EBankingAppTest {
    private static JettyServer server = null;
    private static int TEST_PORT = 8001;
    private static WebDriver driver = null;

    private static String loanPageUrl = "http://localhost:" + TEST_PORT + "/loanPage.html";

    @BeforeClass
    public static void setup() {
        driver = new HtmlUnitDriver(BrowserVersion.CHROME, true) {
            @Override
            protected WebClient newWebClient(BrowserVersion version) {
                WebClient webClient = super.newWebClient(version);
                webClient.getOptions().setThrowExceptionOnScriptError(false);

                java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);
                java.util.logging.Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.OFF);

                return webClient;
            }
        };
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        server = new JettyServer(TEST_PORT);
        server.start();
    }

    @AfterClass
    public static void tearDown() {
        driver.close();
        server.stop();
    }

    @Test
    public void testEmptyLoanDetails() {
        LoanDetails loanDetails = new LoanDetails("", "", "", "", new Random().nextInt(100));
        String actualCode = EBankingApp.applyLoan(driver, loanPageUrl, loanDetails);

        Assert.assertTrue("Expected: " + loanDetails.hashCode() + " Actual: " + actualCode, actualCode.equals(String.valueOf(loanDetails.hashCode())));
    }

    @Test
    public void testCorrectLoanDetails() {
        LoanDetails loanDetails = new LoanDetails("Hacker", "Rank", "h@r.com", "Commercial", new Random().nextInt(7) + 1);
        String actualCode = EBankingApp.applyLoan(driver, loanPageUrl, loanDetails);

        Assert.assertTrue("Expected: " + loanDetails.hashCode() + " Actual: " + actualCode, String.valueOf(loanDetails.hashCode()).equals(actualCode));
    }

    @Test
    public void testIncorrectDetails() {
        LoanDetails loanDetails = new LoanDetails("Hacker", "Rank", "hacker@r", "Test", new Random().nextInt(100) + 1);
        String actualCode = EBankingApp.applyLoan(driver, loanPageUrl, loanDetails);
        loanDetails.setLoanType("");

        Assert.assertTrue("Expected: " + loanDetails.hashCode() + " Actual: " + actualCode, actualCode.equals(String.valueOf(loanDetails.hashCode())));
    }
}
