package com.hackerrank.selenium.server;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DashboardServlet extends HttpServlet {
    public static final List<String> dental_list = new ArrayList<>(Arrays.asList(new String[]{
            "/dental/doctors.html",
            "/dental/nurses.html",
            "/dental/patients.html",
            "/dental/pharmacists.html",
    }));

    public static final List<String> general_list = new ArrayList<>(Arrays.asList(new String[]{
            "/general/patients.html",
            "/general/nurses.html",
            "/general/doctors.html",
            "/general/pharmacists.html"
    }));
    private static final String head = "<html>\n" +
            "<head>\n" +
            "    <title>Hackerrank Hospital-Dashboard</title>\n" +
            "    <link href=\"https://cdn.jsdelivr.net/npm/h8k-design@latest/dist/index.css\" rel=\"stylesheet\"/>\n" +
            "    <script src=\"https://cdn.jsdelivr.net/npm/h8k-components/dist/h8k-components/h8k-components.esm.js\"\n" +
            "            type=\"module\"></script>\n" +
            "    <script nomodule src=\"https://cdn.jsdelivr.net/npm/h8k-components/dist/h8k-components/h8k-components.js\"></script>\n" +
            "    <link rel=\"stylesheet\" href=\"css/style.css\" />\n" +
            "    <style>\n" +
            "        .paragraph p {\n" +
            "            font-size: 0.95em;\n" +
            "            text-align: justify;\n" +
            "        }\n" +
            "        table tbody tr td {\n" +
            "            padding: 16px;\n" +
            "        }\n" +
            "        strong {\n" +
            "        color:Green\n" +
            "        }\n" +
            "    </style>\n" +
            "</head>\n" +
            "<body>\n" +
            "<h8k-navbar fixed header=\"Hackerrank Hospital: Dashboard\"></h8k-navbar>\n" +
            "\n" +
            "<div class=\"mx-auto w-50 mt-100 paragraph\">\n" +
            "<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore</p>\n" +
            "</div>\n" +
            "\n" +
            "<div class=\"card w-50 mx-auto mt-50\">";
    private static List<String> general_invalid_urls = new ArrayList<>();
    private static List<String> dental_invalid_urls = new ArrayList<>();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("Server->Processing URL: " + request.getRequestURL());

        response.setHeader("Cache-Control", "private, no-cache");
        response.setHeader("Pragma", "no-cache");
        response.setCharacterEncoding("UTF-8");

        if ("/".equals(request.getRequestURI())) {
            StringBuilder builder = new StringBuilder();
            builder.append(head);
            response.getWriter().write(builder.toString());
        }

        if ("/dashboard".equals(request.getRequestURI())) {
            if (request.getParameter("general_invalid_urls") != null) {
                general_invalid_urls = Arrays.asList(request.getParameter("general_invalid_urls").split(","));
                dental_invalid_urls = Arrays.asList(request.getParameter("dental_invalid_urls").split(","));

                response.getWriter().write("Done");
            } else {
                StringBuilder builder = new StringBuilder();
                builder.append(head);
                builder.append("\n<table>\n");
                builder.append("\n<tr>");
                for (String url : general_list) {
                    builder.append("<td>");
                    builder.append("<div>\n" +
                            "<h1><strong>General</strong></h1>\n" +
                            "<h3>" + url.substring(9, url.indexOf(".")) + "</h3>\n" +
                            "<h1><a href=\"" + url + "\">476</a></h1>\n" +
                            "                </div>");
                    builder.append("</td>");
                }
                builder.append("</tr>");

                builder.append("\n<tr>");
                for (String url : dental_list) {
                    builder.append("<td>");
                    builder.append("<div>\n" +
                            "<h1><strong>Dental</strong></h1>\n" +
                            "<h3>" + url.substring(8, url.indexOf(".")) + "</h3>\n" +
                            "<h1><a href=\"" + url + "\">476</a></h1>\n" +
                            "                </div>");
                    builder.append("</td>");

                }
                builder.append("</tr>");

                builder.append("</table>\n</div>\n<h8k-navbar header=\"2001-2021\"></h8k-navbar>\n</body>\n</html>");

                response.getWriter().write(builder.toString());
            }
        } else {
            //browser specific page
            StringBuilder builder = new StringBuilder();
            if (dental_invalid_urls.contains(request.getRequestURI())) {
                builder.append("<html>\n" +
                        "<head>\n" +
                        "    <title>Hackerank Hospital-Dashboard</title>\n" +
                        "</head>\n" +
                        "<body>\n" +
                        "<h1>" + request.getRequestURI().substring(1, 7) + " " + request.getRequestURI().substring(8, request.getRequestURI().indexOf(".")) + "</h1>\n" +
                        "</body>\n" +
                        "</html>");
            } else if (general_invalid_urls.contains(request.getRequestURI())) {
                builder.append("<html>\n" +
                        "<head>\n" +
                        "    <title>Hackerrank Hospital:Dashboard</title>\n" +
                        "</head>\n" +
                        "<body>\n" +
                        "<h1>" + request.getRequestURI().substring(1, 8) + " " + request.getRequestURI().substring(9, request.getRequestURI().indexOf(".")) + "</h1>\n" +
                        "</body>\n" +
                        "</html>");
            } else {
                if (dental_list.contains(request.getRequestURI())) {
                    builder.append("<html>\n" +
                            "<head>\n" +
                            "    <title>Hackerrank Hospital-Dashboard</title>\n" +
                            "</head>\n" +
                            "<body>\n" +
                            "<h1>" + request.getRequestURI().substring(1, 7) + " " + request.getRequestURI().substring(8, request.getRequestURI().indexOf(".")) + "</h1>\n" +
                            "</body>\n" +
                            "</html>");
                } else if (general_list.contains(request.getRequestURI())) {
                    builder.append("<html>\n" +
                            "<head>\n" +
                            "    <title>Hackerrank Hospital-Dashboard</title>\n" +
                            "</head>\n" +
                            "<body>\n" +
                            "<h1>" + request.getRequestURI().substring(1, 8) + " " + request.getRequestURI().substring(9, request.getRequestURI().indexOf(".")) + "</h1>\n" +
                            "</body>\n" +
                            "</html>");
                }
            }
            response.getWriter().write(builder.toString());
        }
    }
}
