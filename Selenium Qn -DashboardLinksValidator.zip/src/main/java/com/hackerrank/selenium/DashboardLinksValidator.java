package com.hackerrank.selenium;

import org.openqa.selenium.WebDriver;

import java.util.List;

public class DashboardLinksValidator {

    public static List<String> findAllDashboardLinks(WebDriver driver, String homePageUrl) {
        return null;
    }

    public static List<String> findAllValidDashboardLinks(WebDriver driver, String homePageUrl) {
        return null;
    }

    public static List<String> findAllInvalidDashboardLinks(WebDriver driver, String homePageUrl) {
        return null;
    }
}
