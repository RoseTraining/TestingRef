package com.hackerrank.selenium;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.hackerrank.selenium.server.JettyServer;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.stream.Collectors;

import static com.hackerrank.selenium.server.DashboardServlet.dental_list;
import static com.hackerrank.selenium.server.DashboardServlet.general_list;

public class DashboardLinksValidatorTest {
    private static JettyServer server = null;
    private static int TEST_PORT = 8001;
    private static WebDriver driver = null;
    private static String pagUrl = null;
    private static Integer seed;

    @BeforeClass
    public static void setup() {
        driver = new HtmlUnitDriver(BrowserVersion.CHROME, true) {
            @Override
            protected WebClient newWebClient(BrowserVersion version) {
                WebClient webClient = super.newWebClient(version);
                webClient.getOptions().setThrowExceptionOnScriptError(false);

                java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);
                java.util.logging.Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.OFF);

                return webClient;
            }
        };
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        server = new JettyServer(TEST_PORT);
        server.start();

        pagUrl = "http://localhost:" + TEST_PORT + "/dashboard";

        //rands
        seed = new Random().nextInt(4) + 1;
        driver.get(pagUrl + "?general_invalid_urls=" + String.join(",", general_list.subList(0, seed)) + "&dental_invalid_urls=" + String.join(",", dental_list.subList(0, seed)));
    }

    @AfterClass
    public static void tearDown() {
        driver.close();
        server.stop();
    }

    @Test
    public void testFindAllDashboardLinks() {
        List<String> actual = DashboardLinksValidator.findAllDashboardLinks(driver, pagUrl);

        List<String> expected = new ArrayList<>();
        expected.addAll(general_list);
        expected.addAll(dental_list);
        expected = expected.stream().map(u -> "http://localhost:" + TEST_PORT + u).collect(Collectors.toList());

        System.out.println(" Actual: \n" + String.join("\n", actual) + "\n Expected: \n" + String.join("\n", expected));

        Assert.assertEquals(expected.size(), actual.size());
        for (String actualLink : actual) {
            Assert.assertTrue(expected.contains(actualLink));
        }
    }

    @Test
    public void testFindAllValidDashboardLinks() {
        List<String> actual = DashboardLinksValidator.findAllValidDashboardLinks(driver, pagUrl);

        List<String> expected = new ArrayList<>();
        expected.addAll(general_list);
        expected.addAll(dental_list);
        expected.removeAll(general_list.subList(0, seed));
        expected.removeAll(dental_list.subList(0, seed));
        expected = expected.stream().map(u -> "http://localhost:" + TEST_PORT + u).collect(Collectors.toList());

        System.out.println(" Actual: \n" + String.join("\n", actual) + "\n Expected: \n" + String.join("\n", expected));

        Assert.assertEquals(expected.size(), actual.size());
        for (String actualLink : actual) {
            Assert.assertTrue(expected.contains(actualLink));
        }
    }

    @Test
    public void testFindAllInvalidDashboardLinks() {
        List<String> actual = DashboardLinksValidator.findAllInvalidDashboardLinks(driver, pagUrl);

        List<String> expected = new ArrayList<>();
        expected.addAll(general_list.subList(0, seed));
        expected.addAll(dental_list.subList(0, seed));
        expected = expected.stream().map(u -> "http://localhost:" + TEST_PORT + u).collect(Collectors.toList());

        System.out.println(" Actual: \n" + String.join("\n", actual) + "\n Expected: \n" + String.join("\n", expected));

        Assert.assertEquals(expected.size(), actual.size());
        for (String actualLink : actual) {
            Assert.assertTrue(expected.contains(actualLink));
        }
    }
}
