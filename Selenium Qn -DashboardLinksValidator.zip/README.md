## Environment:
- Java version: 17
- Maven version: 3.*
- Selenium HtmlUnitDriver: 2.52.0

## Read-Only Files:
- src/test/*
- website/*
- src/main/java/com/hackerrank/selenium/server/*

## Requirements:
In this challenge, you are going to use selenium web driver, the HtmlUnitDriver, which uses HtmlUnit headless browser. So you neither need to setup the browsers like Firefox, Chrome nor a web driver executables like FirefoxDriver, ChromeDriver.
You are given a website with a dashboard on the home page. The dashboard displays many links to other pages. Given condition is that the title of the dashboard page and all the pages linked from the dashboard must be same. So here your job is to find the valid and invalid links present on the dashboard.

There is a class `DashboardLinksValidator` which has 3 methods:
 
`List<String> findAllDashboardLinks(WebDriver driver, String homePageUrl)`:
 - it needs to return all the links present on the give page.
 - return type of this method is List URLs. A link URL must be absolute. 
 - for example: ["http://localhost:8080/general/doctors.html", ...].
 
`List<String> findAllValidDashboardLinks(WebDriver driver, String homePageUrl)`:
 - it needs to return all the valid links present on the give page. A link is valid if it has same title as the page it's present on.
 - return type of this method is List URLs. A link URL must be absolute. 
 - for example: ["http://localhost:8080/dental/patients.html",...]
 
 `List<String> findAllInvalidDashboardLinks(WebDriver driver, String homePageUrl)`:
 - it needs to return all the invalid links present on the give page. A link is invalid if it has different title then the page it's present on.
 - return type of this method is List URLs. A link URL must be absolute. 
 - for example: ["http://localhost:8080/general/nurses.html",...]
  
These methods have 2 parameters, one web driver and another website URL.

There are tests for testing correctness of each methods. So you can make use of these tests while debugging/checking your implementation.
The test's setup method bootstraps an embedded jetty server and deploys small web app which displays randomly generated website. 
The example website is given in the `website` folder where you can view the structure of dashboard page at `website/index.html` but data displayed are random and will change on every refresh.

The provided page will look like: 

![web page](webPage.png)

Your task is to complete the implementation of those 3 methods so that the unit tests pass while running the tests.

## Commands
- run: 
```bash
mvn clean package && java -jar target/selenium-java-dashboard-links-validation-1.0.jar
```
- install: 
```bash
mvn clean install
```
- test: 
```bash
mvn clean test
```