package com.hackerrank.selenium;

import org.openqa.selenium.WebDriver;

public class WebAuthenticator {

    public static String authenticateAndGetText(WebDriver driver, String pageUrl) {
        // complete implementation, authentication and return body text.
        return "";
    }
}
