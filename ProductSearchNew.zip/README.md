## Environment
- Java version: 17
- Maven version: 3.*
- Selenium HtmlUnitDriver: 2.52.0

## Read-Only Files
- src/test/*
- website/*
- src/main/java/com/hackerrank/selenium/server/*

- ## Commands
- run: 
```bash
 mvn clean package -DskipTests && java -jar target/selenium-java-product-search-1.0.jar
```
- install: 
```bash
mvn clean install
```
- test: 
```bash
mvn clean test
```

## Requirements:
In this challenge, you are going to use the Selenium WebDriver, the _HtmlUnitDriver_, which uses the _HtmlUnit_ headless browser. This means you don't need to set up a browser (like Firefox or Chrome) or a web driver executable (like FirefoxDriver or ChromeDriver). Every web page has web elements (aka DOM objects) with unique names or IDs. Names are usually unique, but this is not a restriction.

You are given a link to a product search page. The website has a search page where you can type a product name like _Laptop_, and it responds with a table of products.

There is a class `ProductSearch` that has 2 methods. Both of the methods share the following requirements:

- There are 3 parameters: the web driver, the website URL, and the product name to enter.
- Browse to the searchPageUrl and fill the productName in the input textbox with the id search.
- Submit the search form and receive the result page.
  - The result page will contain a table where each row represents a product.
  - The result page source code is like website/resultPage.html
- Extract the product vendor and product price columns.

The methods have the following requirements that differ:

`Map<String,Integer> searchProduct(WebDriver driver, String searchPageUrl, String productName)`:
- Return a map of product vendors and product prices.

`String searchMinimumPricedProduct(WebDriver driver, String searchPageUrl, String productName)`:
- Return the name of the product vendor with the minimum-priced product.

There are tests for the correctness of each method. You can make use of these tests while debugging/checking your implementation. The test's setup method bootstraps an embedded jetty server and deploys a small web app that displays a randomly generated website. The example website is given in the `website` folder where you can view the structure of the search and result pages, but the data displayed is random and will change on every refresh.

The provided search page will look like this: 

![web page](searchPage.png)

The provided result page will look like this: 

![web page](resultPage.png)

Your task is to complete the implementation of these 2 methods so that the unit tests pass while running the tests.
