## Read-only Files
The following files are marked read-only. You cannot edit these files
in the editor; however, it is possible from the terminal. You must not
modify or delete these files because doing so results in a zero score.

* src/main/java/com/hackerrank/selenium/server/JettyServer.java
* src/main/java/com/hackerrank/selenium/server/ProductSearchServlet.java
* src/test/java/com/hackerrank/selenium/ProductSearchTest.java
* website/resultPage.html
* website/searchPage.html