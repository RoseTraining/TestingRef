package com.hackerrank.selenium;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.hackerrank.selenium.server.JettyServer;
import com.hackerrank.selenium.server.ProductSearchServlet;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.stream.Collectors;

public class ProductSearchTest {
    private static JettyServer server = null;
    private static int TEST_PORT = 8001;
    private static WebDriver driver = null;

    private static String searchPageUrl = "http://localhost:" + TEST_PORT + "/searchPage.html";
    private static String seedPageUrl = "http://localhost:" + TEST_PORT + "/result/seed";

    private static Integer productSeed = 0;
    private static Integer priceSeed = 0;

    @BeforeClass
    public static void setup() {
        driver = new HtmlUnitDriver(BrowserVersion.CHROME, true) {
            @Override
            protected WebClient newWebClient(BrowserVersion version) {
                WebClient webClient = super.newWebClient(version);
                webClient.getOptions().setThrowExceptionOnScriptError(false);

                java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);
                java.util.logging.Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.OFF);

                return webClient;
            }
        };
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        server = new JettyServer(TEST_PORT);
        server.start();

        //rands
        productSeed = new Random().nextInt(100) % 3;
        priceSeed = new Random().nextInt(100);

        //set seeds
        driver.get(seedPageUrl + "?priceSeed="+priceSeed);
    }

    @AfterClass
    public static void tearDown() {
        driver.close();
        server.stop();
    }

    @Test
    public void testSearchProduct() {
        Map<String,Integer> actual = ProductSearch.searchProduct(driver, searchPageUrl, ProductSearchServlet.productList.get(productSeed));

        Map<String,Integer> expected = ProductSearchServlet.productListMap.get(ProductSearchServlet.productList.get(productSeed));
        expected = expected.entrySet().stream().collect(Collectors.toMap(p -> p.getKey(), p -> p.getValue()+priceSeed));

        System.out.println(" Actual: \n" + actual + "\n Expected: \n" + expected);

        Assert.assertEquals(expected.size(), actual.size());
        for (Map.Entry<String,Integer> actualProduct : actual.entrySet()) {
            Assert.assertTrue(expected.get(actualProduct.getKey()).equals(actualProduct.getValue()));
        }
    }

    @Test
    public void testSearchMinPricedProduct() {
        String actual = ProductSearch.searchMinimumPricedProduct(driver, searchPageUrl, ProductSearchServlet.productList.get(productSeed));

        Map<String,Integer> map = ProductSearchServlet.productListMap.get(ProductSearchServlet.productList.get(productSeed));
        String expected = map.entrySet().stream().sorted(Map.Entry.comparingByValue())
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new)) .entrySet().iterator().next().getKey();

        System.out.println(" Actual: \n" + actual + "\n Expected: \n" + expected);

        Assert.assertEquals(expected, actual);
    }
}
