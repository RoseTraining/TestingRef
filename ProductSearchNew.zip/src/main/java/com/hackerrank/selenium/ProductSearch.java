package com.hackerrank.selenium;

import org.openqa.selenium.*;

import java.util.*;


public class ProductSearch {

    public static Map<String,Integer> searchProduct(WebDriver driver, String searchPageUrl, String productName) {
        driver.get(searchPageUrl);
        driver.findElement(By.id("search")).sendKeys(productName);
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        List<WebElement> productN=driver.findElements(By.xpath("/html/body/div[2]/div/table/tbody/tr/td[1]"));
        List<WebElement> productV=driver.findElements(By.xpath("/html/body/div[2]/div/table/tbody/tr/td[2]"));
        List<WebElement> productP=driver.findElements(By.xpath("/html/body/div[2]/div/table/tbody/tr/td[3]"));
        Map<String,Integer> map=new HashMap<>();
        for(int i=0;i<productN.size();i++){
            map.put(productV.get(i).getText(),Integer.parseInt(productP.get(i).getText()));
        }
        return map;
        
        
    }

    public static String searchMinimumPricedProduct(WebDriver driver, String searchPageUrl, String productName) {
        driver.get(searchPageUrl);
        driver.findElement(By.id("search")).sendKeys(productName);
        driver.findElement(By.xpath("//button[@type='submit']")).click();
         List<WebElement> productV=driver.findElements(By.xpath("/html/body/div[2]/div/table/tbody/tr/td[2]"));
        List<WebElement> productP=driver.findElements(By.xpath("/html/body/div[2]/div/table/tbody/tr/td[3]"));
        List<Integer> price=new ArrayList<>();
        for(WebElement p:productP){
            price.add(Integer.parseInt(p.getText()));
        }
        Collections.sort(price);
        int min=price.get(0);
        String res="";
        for(int i=0;i<productP.size();i++){
            if(Integer.parseInt(productP.get(i).getText())==min){
                res=productV.get(i).getText();
            }
        }
        return res;
         
       
                
    }
}
