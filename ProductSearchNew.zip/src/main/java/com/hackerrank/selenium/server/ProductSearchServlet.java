package com.hackerrank.selenium.server;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.*;

public class ProductSearchServlet extends HttpServlet {
    private static Integer priceSeed = 0;

    public static final List<String> productList = new ArrayList<>(Arrays.asList(new String[]{
            "Laptop",
            "Mobile",
            "Bag",
    }));

    public static final Map<String,Integer> laptopList = new HashMap(){
        {
            put("Dell",400);
            put("HP",700);
            put("Apple",900);
            put("H5",300);
            put("ABC",200);
            put("Samsung",600);
        }
    };

    public static final Map<String,Integer> mobileList = new HashMap(){
        {
            put("Samsung", 400);
            put("Android", 600);
            put("iPhone", 900);
            put("Colors", 100);
            put("Hawai", 200);
        }
    };

    public static final Map<String,Integer> bagList = new HashMap(){
        {
            put("Bag1", 60);
            put("Bag3", 70);
            put("Bag2", 30);
            put("Bag",  50);
        }
    };

    public static final Map<String,Map<String,Integer>> productListMap = new HashMap(){
        {
            put("Laptop", laptopList);
            put("Mobile", mobileList);
            put("Bag", bagList);
        }
    };

    private static final String head = "<html>\n" +
            "<head>\n" +
            "    <title>Hackerrank Store: Search</title>\n" +
            "    <link href=\"https://cdn.jsdelivr.net/npm/h8k-design@latest/dist/index.css\" rel=\"stylesheet\"/>\n" +
            "    <script src=\"https://cdn.jsdelivr.net/npm/h8k-components/dist/h8k-components/h8k-components.esm.js\"\n" +
            "            type=\"module\"></script>\n" +
            "    <script nomodule src=\"https://cdn.jsdelivr.net/npm/h8k-components/dist/h8k-components/h8k-components.js\"></script>\n" +
            "    <link href=\"css/style.css\" rel=\"stylesheet\"/>\n" +
            "    <style>\n" +
            "        .paragraph p {\n" +
            "            font-size: 0.95em;\n" +
            "            text-align: justify;\n" +
            "        }\n" +
            "        table tbody tr td {\n" +
            "            padding: 16px;\n" +
            "        }\n" +
            "        strong {\n" +
            "        color:Green\n" +
            "        }\n" +
            "\n" +
            "\n" +
            "    </style>\n" +
            "</head>\n" +
            "<body>\n" +
            "<h8k-navbar fixed header=\"Hackerrank Store: Search\"></h8k-navbar>\n" +
            "\n" +
            "<div class=\"mx-auto w-50 mt-100 paragraph\">\n" +
            "    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore</p>\n" +
            "</div>\n" +
            "\n" +
            "<!--Search form-->\n" +
            "<div align=\"center\">\n" +
            "    <div>\n" +
            "        <table>";

    public static final String footer = "</table>\n" +
            "    </div>\n" +
            "</div>\n" +
            "<!--Search form end-->\n" +
            "\n" +
            "<h8k-navbar header=\"2001-2021\"></h8k-navbar>\n" +
            "</body>\n" +
            "</html>";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setHeader("Cache-Control", "private, no-cache");
        response.setHeader("Pragma", "no-cache");
        response.setCharacterEncoding("UTF-8");

        if("/result/seed".equals(request.getRequestURI())){
            System.out.println("Server->Processing URL: " + request.getRequestURL());
            priceSeed = Integer.parseInt(request.getParameter("priceSeed"));
        } else if ("/result/".equals(request.getRequestURI())) {
            System.out.println("Server->Processing URL: " + request.getRequestURL());
            String product = request.getParameter("search");
            StringBuilder builder = new StringBuilder();

            builder.append(head);
            builder.append("<tr>");
            builder.append("<th>");
            builder.append("Product Name");
            builder.append("</th>");

            builder.append("<th>");
            builder.append("Product Vendor");
            builder.append("</th>");

            builder.append("<th>");
            builder.append("Product Price");
            builder.append("</th>");
            builder.append("</tr>");

            for (Map.Entry<String,Integer> e : productListMap.get(product).entrySet()) {
                builder.append("<tr>");
                builder.append("<td>");
                builder.append(product);
                builder.append("</td>");

                builder.append("<td>");
                builder.append(e.getKey());
                builder.append("</td>");

                builder.append("<td>");
                builder.append(e.getValue()+priceSeed);
                builder.append("</td>");
                builder.append("</tr>");
            }

            builder.append(footer);
            response.getWriter().write(builder.toString());
        }
    }
}
