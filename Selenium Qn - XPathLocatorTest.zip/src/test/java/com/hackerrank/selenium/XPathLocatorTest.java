package com.hackerrank.selenium;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.hackerrank.selenium.server.JettyServer;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class XPathLocatorTest {
    static JettyServer server = null;
    private static int TEST_PORT = 8001;
    static WebDriver driver = null;
    static String pagUrl = "http://localhost:" + TEST_PORT + "/home.html";
    ;

    @BeforeClass
    public static void setup() {
        driver = new HtmlUnitDriver(BrowserVersion.CHROME, true) {
            @Override
            protected WebClient newWebClient(BrowserVersion version) {
                WebClient webClient = super.newWebClient(version);
                webClient.getOptions().setThrowExceptionOnScriptError(false);

                java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);
                java.util.logging.Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.OFF);

                return webClient;
            }
        };
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        server = new JettyServer(TEST_PORT);
        server.start();
    }

    @Test
    public void testAbsoluteXPathForInput() {
        String xpath = XPathLocator.absoluteXPathForInput(driver, pagUrl);

        assertTrue(xpath.contains("html"));

        driver.get(pagUrl);
        assertEquals(5, driver.findElements(By.xpath(xpath)).size());
    }

    @Test
    public void testRelativeXPathForInput() {
        String xpath = XPathLocator.relativeXPathForInput(driver, pagUrl);

        assertTrue(!xpath.contains("html"));

        driver.get(pagUrl);
        assertEquals(5, driver.findElements(By.xpath(xpath)).size());
    }


    @AfterClass
    public static void tearDown() {
        driver.close();
    }
}
