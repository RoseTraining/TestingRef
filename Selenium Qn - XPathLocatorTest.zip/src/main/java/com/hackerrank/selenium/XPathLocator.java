package com.hackerrank.selenium;

import org.openqa.selenium.WebDriver;

public class XPathLocator {

    public static String relativeXPathForInput(WebDriver driver, String pageUrl) {
        //return xpath
        return null;
    }

    public static String absoluteXPathForInput(WebDriver driver, String pageUrl) {
        //return xpath
        return null;
    }
}
