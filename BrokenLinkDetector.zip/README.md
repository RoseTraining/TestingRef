## Environment:
- Java version: 17
- Maven version: 3.*
- Selenium HtmlUnitDriver: 2.52.0

## Read-Only Files:
- src/test/*
- website/*
- src/main/java/com/hackerrank/selenium/server/*

## Requirements:
In this challenge, you are going to use the Selenium WebDriver, the HtmlUnitDriver, which uses the HtmlUnit headless browser. This means you don't need to set up the browser (like Firefox or Chrome) nor a web driver executable (like FirefoxDriver or ChromeDriver). Every web page has web elements (aka DOM objects) with unique names or ids.

Assume you are the owner of a website and you want your site to be free of broken links. A link is broken if it returns status code 404.

There is a class `BrokenLinkDetector` that has 3 methods:

1. `findBrokenImages`: returns all the broken images on the given page.
2. `findBrokenAnchors`: returns all the broken anchors on the given page.
3. `findBrokenIFrames`: returns all the broken iframes on the given page.

These methods have 2 parameters, one web driver and one website URL. The supplied website's home page will look like the following:

![web page](webPage.png)

Your task is to complete the implementation of those 3 methods so that the unit tests pass while running the tests.

**Hint:** There are tests for testing the correctness of each method. You can make use of these tests while debugging and checking your implementation. The test's setup method bootstraps an embedded jetty server and deploys `website`. 

## Commands
- run: 
```bash
mvn clean package && java -jar target/selenium-java-broken-link-detector-1.0.jar
```
- install: 
```bash
mvn clean install
```
- test: 
```bash
mvn clean test
```
