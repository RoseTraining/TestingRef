package com.hackerrank.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class BrokenLinkDetector {

    public static List<WebElement> findBrokenImages(WebDriver driver, String pageUrl) {
        return null;
    }

    public static List<WebElement> findBrokenAnchors(WebDriver driver, String pageUrl) {
        return null;
    }

    public static List<WebElement> findBrokenIFrames(WebDriver driver, String pageUrl) {
        return null;
    }
}
