package com.hackerrank.selenium;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.hackerrank.selenium.server.JettyServer;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class BrokenLinkDetectorTest {
    static JettyServer server = null;
    private static int TEST_PORT = 8001;
    private static WebDriver driver = null;

    private static String pagUrl = "http://localhost:" + TEST_PORT + "/home.html";

    @BeforeClass
    public static void setup() {
        driver = new HtmlUnitDriver(BrowserVersion.CHROME, true) {
            @Override
            protected WebClient newWebClient(BrowserVersion version) {
                WebClient webClient = super.newWebClient(version);
                webClient.getOptions().setThrowExceptionOnScriptError(false);

                java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);
                java.util.logging.Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.OFF);

                return webClient;
            }
        };
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        server = new JettyServer(TEST_PORT);
        server.start();
    }

    @Test
    public void testFindBrokenImages(){
        List<WebElement> brokeImages= BrokenLinkDetector.findBrokenImages(driver,pagUrl);
        List<String> data = getData();

        assertEquals(3, brokeImages.size());
        for(WebElement element : brokeImages){
            assertEquals("img",element.getTagName());
            assertTrue(data.contains(element.getAttribute("alt")));
        }
    }

    @Test
    public void testFindBrokenAnchors() {
        List<WebElement> brokenAnchors = BrokenLinkDetector.findBrokenAnchors(driver,pagUrl);
        List<String> data = getData();

        assertEquals(3, brokenAnchors.size());
        for(WebElement element : brokenAnchors){
            assertEquals("a",element.getTagName());
            assertTrue(data.contains(element.getText()));
        }
    }

    @Test
    public void testFindBrokenIFrames() {
        List<WebElement> brokenIFrames = BrokenLinkDetector.findBrokenIFrames(driver,pagUrl);
        List<String> data = getData();

        assertEquals(2, brokenIFrames.size());
        for(WebElement element : brokenIFrames){
            assertEquals("iframe",element.getTagName());
            assertTrue(data.contains(element.getText()));
        }
    }

    @AfterClass
    public static void tearDown() {
        driver.close();
        server.stop();
    }

    private static List<String> getData(){
        List<String> list = new ArrayList<>();
        list.add("Products");
        list.add("About Us");
        list.add("Contact Us");

        list.add("img1");
        list.add("img3");
        list.add("img4");

        list.add("Advert2 Area");
        list.add("Advert3 Area");

        return list;
    }
}
