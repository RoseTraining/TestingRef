## Read-only Files
The following files are marked read-only. You cannot edit these files
in the editor; however, it is possible from the terminal. You must not
modify or delete these files because doing so results in a zero score.

* src/main/java/com/hackerrank/selenium/server/JettyServer.java
* src/test/java/com/hackerrank/selenium/BrokenLinkDetectorTest.java
* website/aboutus.html
* website/contactus.html
* website/css/home.css
* website/home.html
* website/iframes/frame1.html
* website/images/fake2.png
* website/products/product.html
* website/services/services.html