## Environment:
- Java version: 17
- Maven version: 3.*
- Selenium HtmlUnitDriver: 2.52.0

## Read-Only Files:
- src/test/*
- website/*
- src/main/java/com/hackerrank/selenium/server/*

## Requirements:
In this challenge, you are going to use selenium web driver, the HtmlUnitDriver, which uses HtmlUnit headless browser. So you neither need to setup the browsers like Firefox, Chrome nor a web driver executables like FirefoxDriver, ChromeDriver.
You are given a product search website. The website has search page where you can type a product name like `Laptop` and get a table of products on response.

There is a class `ProductSearch` which has 2 methods:
 
`Map<String,Integer> searchProduct(WebDriver driver, String searchPageUrl, String productName)`:
 - browse the `searchPageUrl` and fill the `productName` in the input textbox having id `search`.
 - submit the search form and response will be the result page.
 - result page will have a table in which each row represents a product and you have to extract product vendor and product price column
 - result page source code is like `website/resultPage.html`
 - it should return a map of product vendor and product price
 
`String searchMinimumPricedProduct(WebDriver driver, String searchPageUrl, String productName)`:
 - browse the `searchPageUrl` and fill the `productName` in the input textbox having id `search`.
 - submit the search form and response will be the result page.
 - result page will have a table in which each row represents a product and you have to extract product vendor and product price column
 - result page source code is like `website/resultPage.html`
 - it should return a minimum priced product vendor name
  
These methods have 3 parameters, web driver,website URL, and product name to be searched.

There are tests for testing correctness of each methods. So you can make use of these tests while debugging/checking your implementation.
The test's setup method bootstraps an embedded jetty server and deploys small web app which displays randomly generated website. 
The example website is given in the `website` folder where you can view the structure of search page and result page but data displayed are random and will change on every refresh.

The provided search page will look like: 

![web page](searchPage.png)

The provided result page will look like: 

![web page](resultPage.png)

Your task is to complete the implementation of those 2 methods so that the unit tests pass while running the tests.

## Commands
- run: 
```bash
 mvn clean package -DskipTests && java -jar target/selenium-java-product-search-1.0.jar
```
- install: 
```bash
mvn clean install
```
- test: 
```bash
mvn clean test
```