package com.hackerrank.selenium;

import org.openqa.selenium.WebDriver;

import java.util.Map;

public class ProductSearch {

    public static Map<String,Integer> searchProduct(WebDriver driver, String searchPageUrl, String productName) {
        return null;
    }

    public static String searchMinimumPricedProduct(WebDriver driver, String searchPageUrl, String productName) {
        return null;
    }
}
