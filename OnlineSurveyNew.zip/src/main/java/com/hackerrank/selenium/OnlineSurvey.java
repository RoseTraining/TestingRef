package com.hackerrank.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class OnlineSurvey {

    public static void fillDateOfBirth(WebDriver driver, String pageUrl) {
      driver.get(pageUrl);
    Select month=new Select(driver.findElement(By.id("month")));
    month.selectByVisibleText("November");
     Select day=new Select(driver.findElement(By.id("day")));
    day.selectByVisibleText("4");
     Select year=new Select(driver.findElement(By.id("year")));
    year.selectByVisibleText("2003");

        
    }

    public static void answerQuestions(WebDriver driver, String pageUrl) {
        // complete implementation
        driver.get(pageUrl);
        driver.findElement(By.xpath("//input[@value='Java']")).click();
         driver.findElement(By.xpath("//input[@value='Linux']")).click();
          driver.findElement(By.xpath("//input[@value='Eclipse IDE']")).click();
         // driver.findElement(By.xpath("//button[@type='submit']")).submit//();
    }
}