package com.hackerrank.selenium;

import org.openqa.selenium.WebDriver;

import java.util.List;

public class HealthcareAnalytics {

    public static List<String> findAmountMismatchedPatients(WebDriver driver, String patientPageUrl) {
        return null;
    }
}
